#! /usr/bin/env python
# -*- coding: utf-8 -*-

#####################################
# Waveform Data Format Reader Class #
#####################################
import struct

class CReaderNgspice(object):
    def __init__(self):
        self.filename = None

    def set_file(self, fname):
        self.filename = fname
        return True

    def get_labels(self):
        try:
            res = []
            with open(self.filename, 'r') as f:
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("No. Variables:"):
                        NVARS=int(l[14:])
                        break
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("No. Points:"):
                        NPOINTS=int(l[11:])
                        break
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("Variables:"):
                        break
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("Binary:"):
                        break
                    res.append(l.strip().split()[1])
                l=len(res)
                if l < NVARS:
                    NVARS = l
                    res = res[:NVARS]
            return res
        except:
            return []

    def get_data(self,n):
        try:
            res = []
            with open(self.filename, 'rb') as f:
                NVARS=0
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("No. Variables:"):
                        NVARS=int(l[14:])
                        break
                NPOINTS=0
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("No. Points:"):
                        NPOINTS=int(l[11:])
                        break
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    if l.startswith("Binary:"):
                        break
                f.seek(8*n,1)
                for i in xrange(NPOINTS):
                    a, = struct.unpack("d", f.read(8))
                    res.append(a)
                    f.seek(8*(NVARS-1),1)
            return res
        except:
            return []



if __name__ == '__main__':
    r = CReaderNgspice()
    r.set_file("t.raw")
    for n in r.get_labels():
        print n
    a=r.get_data(4)
    print a[:200]

