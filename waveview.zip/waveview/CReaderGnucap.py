#####################################
# Waveform Data Format Reader Class #
#####################################

class CReaderGnucap(object):
    def __init__(self):
        self.filename = None

    def set_file(self, fname):
        self.filename = fname
        return True

    def get_labels(self):
        try:
            res = []
            with open(self.filename, 'r') as f:
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    l = l.strip()
                    if l.startswith('#'):
                       res = (l.lstrip('#')).split()
                       break
                return res
        except:
            return []

    def get_data(self,n):
        try:
            res = []
            with open(self.filename, 'r') as f:
                while True:
                    l = f.readline()
                    if not l:
                        return []
                    l = l.strip()
                    if l.startswith('#'):
                        break
                res = [ float((l.split())[n])
                        for l in f if not (l.strip()).startswith('#') ]
            return res
        except:
            return []

