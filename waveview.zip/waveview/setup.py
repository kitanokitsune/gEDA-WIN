# setup.py for gwave2.py

# python setup.py py2exe

import os
import py2exe
from distutils.core import setup
import matplotlib


py2exe_options = {
    "compressed": 1,
    "bundle_files": 3,
    "includes" : [ "matplotlib.backends.backend_qt4agg" ],
    "excludes": ['astroid', 'Babel', 'backports.functools-lru-cache', 'boost-python', 'boto', 'boto3', 'botocore', 'bsddb', 'colorama', 'configparser', 'colorama', 'curses', 'Cython', 'distribute', 'doctest', 'docutils', 'easygui', 'easygui-qt', 'ecdsa', 'Fabric', 'fonttools', 'futures', 'isort', 'jmespath', 'Kivy', 'Kivy-Garden', 'lazy-object-proxy', 'mccabe', 'mecab-python', 'mpmath', 'networkx', 'nose', 'opencv-python', 'OpenGL', 'pandas', 'paramiko', 'PIL', 'Pillow', 'pip', 'ply', 'Polygon', 'Polygon2', 'progressbar', 'ptable', 'PTable', 'py2exe', 'PyAudio', 'PyBrain', 'pycrypto', 'pycurl', 'pydoc', 'pyflakes', 'PyInstaller', 'pyinstaller', 'pylab', 'pylint', 'pypiwin32', 'PyQt4', 'pyqtgraph', 'python-dateutil', 'PythonMagick', 'pytz', 'pywin.debugger', 'pywin.debugger.dbgcon', 'pywin.dialogs', 'pywin32', 'requests', 'scikit-learn', 'scikits.audiolab', 'scipy', 'seaborn', 'setuptools', 'sqlite3', 'sympy', 'tcl', 'test', 'Tkconstants', 'Tkinter', 'tornado', 'TTFQuery', 'tzdata', 'VPython', 'wheel', 'wrapt', 'wxPython', 'wxPython-common', 'yapf', '_gtkagg', '_ssl', '_tkagg'],
    "dll_excludes": ['MSVCP90.dll']
}

setup(
    options={"py2exe" : py2exe_options},
    data_files=matplotlib.get_py2exe_datafiles(),
    windows=[{"script" : "gwave2.py"}]
)
