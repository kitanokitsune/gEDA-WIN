#! /usr/bin/env python
# -*- coding: utf-8 -*-

'''
Tentative waveform viewer (gwave2.py)
LICENSE:
This software is released under the GPL License.
Copyright (c) 2017 Hiroshi Yoshikawa @ IIC, Hokkaido University
'''

from sys import argv
import os
import numpy as np
### file reader ###
from CWaveFormFile import CWaveFormFile
from CReaderGSpiceUI import CReaderGSpiceUI
from CReaderGnucap import CReaderGnucap
from CReaderNgspice import CReaderNgspice
### control panel ###
from PySide import QtGui
from PySide import QtCore
from PySide.QtCore import Qt
### plot ###
from matplotlib import rcParams, use
rcParams['backend.qt4'] = 'PySide'
use('Qt4Agg')
from matplotlib.lines import Line2D
from matplotlib.text import Text
import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')
#plt.style.use('dark_background')

import gc
gc.enable()
# gc.set_debug(gc.DEBUG_STATS)

##########################################################
class Pane():
    def __init__(self,label=None):
        self.wavefile = None
        self.signals = []
        self.xlabel = ''
        self.panename = ''
        self.axes = None
        self.cursor1x = None
        self.cursor1y = None
        self.cursor2x = None
        self.cursor2y = None
        self.is_lastpane = False
        self.background = None

    def destroy(self):
        del self.signals[:]
        if self.axes:
            self.axes.clear()
            del self.axes.lines
            del self.axes
        self.axes = None
        del self.cursor1x
        del self.cursor1y
        del self.cursor2x
        del self.cursor2y
        self.cursor1x = None
        self.cursor1y = None
        self.cursor2x = None
        self.cursor2y = None
        if self.background:
            del self.background
        self.background = None

    def add(self,y):
        if not y in self.signals:
            self.signals.append(y)

    def remove(self,y):
        if y in self.signals:
            self.signals.remove(y)

    def new_axes(self,fig,n,i,sharex=None):
        # delete old-axes
        if self.axes:
            self.axes.clear()
            del self.axes
        # check pane location
        if n<1 or i<1 or i>n:
            self.axes = None
            return
        self.panename = '#%d' % (i,)
        self.is_lastpane = (i==n)
        # generate new-axes
        if sharex:
            self.axes = fig.add_subplot(n,1,i,sharex=sharex)
        else:
            self.axes = fig.add_subplot(n,1,i)
        return self.axes

    def cursor_update(self,name,on_off):
        if self.cursor1x:
            self.cursor1x.set_visible(on_off)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor1x)
        if self.cursor2x:
            self.cursor2x.set_visible(on_off)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor2x)
        if self.cursor1y:
            if name[0] in self.signals:
                self.cursor1y.set_visible(on_off)
            else:
                self.cursor1y.set_visible(False)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor1y)
        if self.cursor2y:
            if name[1] in self.signals:
                self.cursor2y.set_visible(on_off)
            else:
                self.cursor2y.set_visible(False)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor2y)

    def cursor_blit(self,fig,name, on_off=True):
        if self.background:
            fig.canvas.restore_region(self.background)
        if self.cursor1x:
            self.cursor1x.set_visible(on_off)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor1x)
        if self.cursor2x:
            self.cursor2x.set_visible(on_off)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor2x)
        if self.cursor1y:
            if name[0] in self.signals:
                self.cursor1y.set_visible(on_off)
            else:
                self.cursor1y.set_visible(False)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor1y)
        if self.cursor2y:
            if name[1] in self.signals:
                self.cursor2y.set_visible(on_off)
            else:
                self.cursor2y.set_visible(False)
            if self.axes and self.axes.get_renderer_cache():
                self.axes.draw_artist(self.cursor2y)
        if self.axes:
            fig.canvas.blit(self.axes.bbox)

    def move_cursor(self,name,x,y):
        if self.cursor1x:
            self.cursor1x.set_xdata([x[0],x[0]])
        if self.cursor2x:
            self.cursor2x.set_xdata([x[1],x[1]])
        if self.cursor1y and (name[0] in self.signals):
            self.cursor1y.set_ydata([y[0],y[0]])
        if self.cursor2y and (name[1] in self.signals):
            self.cursor2y.set_ydata([y[1],y[1]])

    def cursor_on(self,name):
        if self.cursor1x:
            self.cursor1x.set_visible(True)
        if self.cursor2x:
            self.cursor2x.set_visible(True)
        if self.cursor1y:
            if name[0] in self.signals:
                self.cursor1y.set_visible(True)
            else:
                self.cursor1y.set_visible(False)
        if self.cursor2y:
            if name[1] in self.signals:
                self.cursor2y.set_visible(True)
            else:
                self.cursor2y.set_visible(False)

    def cursor_off(self):
        if self.cursor1x:
            self.cursor1x.set_visible(False)
        if self.cursor2x:
            self.cursor2x.set_visible(False)
        if self.cursor1y:
            self.cursor1y.set_visible(False)
        if self.cursor2y:
            self.cursor2y.set_visible(False)

    def copy_from_bbox(self,fig):
        if self.axes:
            self.background = fig.canvas.copy_from_bbox(self.axes.bbox)

    def redraw_pane(self):
        # check if axes is available
        if self.axes is None:
            return
        # initialize axes
        self.axes.clear()
        self.axes.set_ylabel(self.panename,fontsize=14)
        self.axes.yaxis.label.set_picker(5)
        if self.xlabel and self.wavefile and self.wavefile.is_valid:
            # plot data
            xdata = self.wavefile.data(self.xlabel)
            xlen = len(xdata)
            sig = None
            for sig in self.signals:
                ydata = self.wavefile.data(sig)
                ylen = len(ydata)
                if xlen == ylen:
                    self.axes.plot(
                        xdata,ydata,lw=0.75,label=sig)
            # show legend
            if sig:
                leg = self.axes.legend(bbox_to_anchor=(1.03, 1.03),
                                 loc='upper left', borderaxespad=0,
                                 fontsize=10)
                if leg:
                    for l in leg.get_lines():
                        l.set_picker(5)
            if xlen:
                self.cursor1x = self.axes.axvline(xdata[0], color='slategray', lw=0.5, ls='-', label='_cursor1x')
                self.cursor2x = self.axes.axvline(xdata[0], color='slategray', lw=0.5, ls='--', label='_cursor2x')
                if sig:
                    self.cursor1y = self.axes.axhline(ydata[0], color='slategray', lw=0.5, ls='-', label='_cursor1y')
                    self.cursor2y = self.axes.axhline(ydata[0], color='slategray', lw=0.5, ls='--', label='_cursor2y')
                self.cursor_update([sig,sig],False)
        # show xlabel and hide xtick
        if self.is_lastpane:
            self.axes.set_xlabel(self.xlabel, fontsize=10)
#        else:
#            plt.setp(self.axes.get_xticklabels(), visible=False)
        plt.setp(self.axes.get_xticklabels(), fontsize=10)
        plt.setp(self.axes.get_yticklabels(), fontsize=10)


# #########################################################
class WaveViewerWindow():
    def __init__(self):
        self.__fig = plt.figure()
        self.__panes = []
        self.__wavefile = None
        self.__wavefilepath = ''
#        self.__labels = []
        self.__xlabel = ''
        self.__lastpane = -1
        self.__need_redraw = False
        self.__curName = [None, None]
        self.__xdata = np.array([])
        self.__ydata = [np.array([]), np.array([])]
        self.__curX = [0, 0]
        self.__curY = [0, 0]
        self.__fig.canvas.mpl_connect('pick_event', self.__OnPick)
        self.__fig.canvas.mpl_connect('button_press_event', self.__OnClickMouse)
        self.__fig.canvas.mpl_connect('button_release_event', self.__OnReleaseMouse)
        self.__fig.canvas.mpl_connect('motion_notify_event', self.__OnMouseMove)
        self.__fig.canvas.mpl_connect('draw_event', self.__OnDrawEvent)
#        self.__fig.canvas.mpl_connect('close_event', self.__OnClickExit)
        self.__show_menu()


    def unitform(self,d):
        u = ''
        if abs(d) < 1.32348e-23:
            return ' 0.000000    '
        elif abs(d) < 0.99999995e-15:
            return '% 13.6e' % (d,)
        elif abs(d) < 0.99999995e-12:
            u = 'f'
            d = d*1.0e+15
        elif abs(d) < 0.99999995e-9:
            u = 'p'
            d = d*1.0e+12
        elif abs(d) < 0.99999995e-6:
            u = 'n'
            d = d*1.0e+9
        elif abs(d) < 0.99999995e-3:
            u = 'u'
            d = d*1.0e+6
        elif abs(d) < 0.99999995:
            u = 'm'
            d = d*1.0e+3
        elif abs(d) < 0.99999995e+3:
            u = ' '
#            d = d*1.0
        elif abs(d) < 0.99999995e+6:
            u = 'k'
            d = d*1.0e-3
        elif abs(d) < 0.99999995e+9:
            u = 'M'
            d = d*1.0e-6
        elif abs(d) < 0.99999995e+12:
            u = 'G'
            d = d*1.0e-9
        elif abs(d) < 0.99999995e+15:
            u = 'T'
            d = d*1.0e-12
        elif abs(d) < 0.99999995e+18:
            u = 'P'
            d = d*1.0e-15
        else:
            return '% 13.6e' % (d,)
        #
        if abs(d) < 9.9999995:
            return '% 8.6f%s   ' % (d,u)
        elif abs(d) < 99.999995:
            return '% 8.5f%s   ' % (d,u)
        else:
            return '% 8.4f%s   ' % (d,u)

    def __copy_from_bbox(self):
        for p in self.__panes:
            p.copy_from_bbox(self.__fig)

    def __cursor_set_visible(self, on_off):
        if on_off and self.__ckCursor.isChecked():
            if self.__curName[0] is None or self.__curName[1] is None:
                for p in self.__panes:
                    p.cursor_on(self.__curName)
        else:
            for p in self.__panes:
                p.cursor_off()

    def __cursor_move(self):
        for p in self.__panes:
            p.move_cursor(self.__curName,self.__curX, self.__curY)

    def __cursor_draw_artist(self):
        on_off = self.__ckCursor.isChecked()
        for p in self.__panes:
            p.cursor_update(self.__curName,on_off)

    def __cursor_blit(self):
        on_off = self.__ckCursor.isChecked()
        for p in self.__panes:
            p.cursor_blit(self.__fig,self.__curName,on_off)

    def __set_cursor(self):
        if self.__curName[0] is None or self.__curName[1] is None:
            return
        self.__cur_text1.setText('C1: %s, %s' % (
            self.unitform(self.__curX[0]),self.unitform(self.__curY[0])))
        self.__cur_text2.setText('C2: %s, %s' % (
            self.unitform(self.__curX[1]),self.unitform(self.__curY[1])))
        self.__cur_text3.setText('diff:%s, %s' % (
            self.unitform(self.__curX[0]-self.__curX[1]),
            self.unitform(self.__curY[0]-self.__curY[1])))
        self.__cursor_move()
        self.__cursor_draw_artist()
        self.__cursor_blit()
        self.__cursor_set_visible(False)
#        for p in self.__panes:
#            if p.axes:
#                p.move_cursor(self.__curName,self.__curX, self.__curY)
#                p.cursor_update(self.__curName,self.__ckCursor.isChecked())
#                p.cursor_blit(self.__fig,self.__curName,self.__ckCursor.isChecked())
#                p.cursor_off()
#        self.__fig.canvas.draw()

    def __refresh_canvas(self):
        if self.__panes and self.__fig.get_axes():
            plt.tight_layout()
            plt.subplots_adjust(right=0.8, left=0.15)
        self.__fig.canvas.draw()
#        gc.collect()

    def __nearest(self,x,y,xdata,ydata):
        if xdata.size == 0:
            return None,None,None
        if xdata.size == 1:
            return 0, 0, 1.0
        x0 = xdata[:-1]-x
        x1 = x-xdata[1:]
        xin, = np.where(x0*x1 >= 0.0)
        if xin.size == 0:
            if x <= xdata.min():
                i = xdata.argmin()
                k = 0.0
            else: # x >= xdata.max()
                i = xdata.argmax()
            k = 0.0
            if i == xdata.size-1:
                i = i-1
                k = 1.0
            return i,i+1,k
        dist = np.zeros(xin.size)
        coeff = np.zeros(xin.size)
        for n in xrange(xin.size):
            i = xin[n]
            if xdata[i] != xdata[i+1]:
                k = (x-xdata[i])/(xdata[i+1]-xdata[i])
            elif ((ydata[i] > y) and (y > ydata[i+1])) or ((ydata[i] < y) and (y < ydata[i+1])):
                k = (y-ydata[i])/(ydata[i+1]-ydata[i])
            elif ((ydata[i] >= ydata[i+1]) and (ydata[i+1] >= y)) or ((ydata[i] <= ydata[i+1]) and (ydata[i+1] <= y)):
                k = 1.0
            else:
                k = 0.0
            coeff[n] = k
            dist[n] = abs((1.0-k)*ydata[i]+k*ydata[i+1]-y)
        n = dist.argmin()
        return xin[n],xin[n]+1,coeff[n]



    # -----------------------------------------------------
    # Public Functions
    # -----------------------------------------------------
    def add_pane(self):
        '''
        === ADD A NEW PANE TO THE END ===
        This method will not update a screen.
        Only one redraw() call is needed after successive add_pane() calls.
        '''
        n = len(self.__panes)
        self.__panes.append(Pane())
        self.__panes[n].wavefile = self.__wavefile
        self.__panes[n].xlabel = self.__xlabel
        self.__lastpane = n
        self.__need_redraw = True

    def del_pane(self):
        '''
        === DELETE THE LAST PANE ===
        This method will not update a screen.
        Only one redraw() call is needed after successive del_pane() calls.
        '''
        n = len(self.__panes)
        if n<1 or self.__lastpane<0 or self.__lastpane >= n:
            return
        self.__panes[self.__lastpane].destroy()
        del self.__panes[self.__lastpane]
        n = len(self.__panes)
        if n < 1:
#            self.__xdata = np.array([])
            self.__ydata = [np.array([]),np.array([])]
            self.__curName = [None,None]
            self.__cur_text1.setText('C1: ( -.------    , -.------    )')
            self.__cur_text2.setText('C2: ( -.------    , -.------    )')
            self.__cur_text3.setText('diff:( -.------    , -.------    )')
            self.__cur_text4.setText('C1=')
            self.__cur_text5.setText('C2=')
            self.__ckCursor.setCheckState(QtCore.Qt.Unchecked)
        if self.__lastpane >= n:
            self.__lastpane = n-1
#        gc.collect()
        self.__need_redraw = True

    def redraw(self):
        '''
        === REDRAW FIGURE AND PANES ===
        This method renews axes before replot.
        '''
        self.__fig.clf()
        n = len(self.__panes)
        # refresh axes
        if n>0:
            sharex = self.__panes[0].new_axes(self.__fig,n,1)
            for i in range(1,n):
#                self.__panes[i].new_axes(self.__fig,n,i+1,sharex)
                self.__panes[i].new_axes(self.__fig,n,i+1)
        # refresh plot
            for p in self.__panes:
                p.redraw_pane()
            if self.__lastpane < n:
                self.__panes[self.__lastpane].axes.yaxis.label.set_color('red')
        self.__refresh_canvas()
        self.__need_redraw = False

    def set_file(self, filename, reader):
        '''
        === SET WAVE FILE ===
        '''
        self.__wavefilepath = os.path.abspath(filename)
        self.__wavefile = CWaveFormFile(file=filename,reader=reader)
        self.__xlabel = ''
        for p in self.__panes:
            p.xlabel = self.__xlabel
            p.wavefile = self.__wavefile
            p.signals = []
        self.__listWidget.clear()
        self.__comboBoxWidget.clear()
        if not self.__wavefile.is_valid:
            self.__wavefile = None
            self.__fig.canvas.set_window_title('(Invalid file)')
        else:
            self.__fig.canvas.set_window_title(
                self.__wavefile.get_basename())
            labels = self.__wavefile.get_labels()
            self.__listWidget.addItems(labels)
            self.__comboBoxWidget.addItems(labels)
            del labels
        self.__ydata = [np.array([]),np.array([])]
        self.__curName = [None,None]
        self.__cur_text1.setText('C1: ( -.------    , -.------    )')
        self.__cur_text2.setText('C2: ( -.------    , -.------    )')
        self.__cur_text3.setText('diff:( -.------    , -.------    )')
        self.__cur_text4.setText('C1=')
        self.__cur_text5.setText('C2=')
        self.__ckCursor.setCheckState(QtCore.Qt.Unchecked)
        # For all panes, set wavefile instance and clear signals
        self.__comboBoxWidget.setCurrentIndex(0)
        self.__xlabel = self.__comboBoxWidget.currentText()
        if self.__wavefile:
            if self.__wavefile.is_valid:
                self.__xdata = np.array(self.__wavefile.data(self.__xlabel))
        for p in self.__panes:
            p.xlabel = self.__xlabel
            p.wavefile = self.__wavefile
            p.signals = []


    # -----------------------------------------------------
    # Docking menu
    # -----------------------------------------------------
    def __show_menu(self):
        root = self.__fig.canvas.manager.window
        panel = QtGui.QWidget()
        self.panel = panel
        hbox = QtGui.QGridLayout(panel)
    # Open File Widget
        btn0 = QtGui.QPushButton('Open...', parent = panel)
        btn0.clicked.connect(self.__OnClickOpenFile)
    # Pane Group Widget
        btn1 = QtGui.QPushButton('Add Pane')
        btn1.clicked.connect(self.__OnClickAddPane)
        btn2 = QtGui.QPushButton('Del Pane')
        btn2.clicked.connect(self.__OnClickDelPane)
        boxLayout = QtGui.QVBoxLayout()
        boxLayout.addWidget(btn1)
        boxLayout.addWidget(btn2)
        grPane = QtGui.QGroupBox("Pane", parent = panel)
        grPane.setLayout(boxLayout)
    # Y-Axis (Wave Group Widget)
        self.__listWidget = QtGui.QListWidget(parent = panel)
        self.__listWidget.addItems([])
        self.__listWidget.setSelectionMode(
            QtGui.QAbstractItemView.ExtendedSelection)
        # self.__listWidget.setCurrentRow(0)
        # self.__listWidget.itemDoubleClicked.connect(onListDblClick)
        btn3 = QtGui.QPushButton('Add Wave')
        btn3.clicked.connect(self.__OnClickAddWave)
        btn4 = QtGui.QPushButton('Del Wave')
        btn4.clicked.connect(self.__OnClickDelWave)
        boxLayout = QtGui.QGridLayout()
        boxLayout.addWidget(self.__listWidget,0,0,2,3)
        boxLayout.addWidget(btn3,0,3,1,1)
        boxLayout.addWidget(btn4,1,3,1,1)
        grWave = QtGui.QGroupBox("Select Y-Data", parent = panel)
        grWave.setLayout(boxLayout)
    # X-Axis
        self.__comboBoxWidget = QtGui.QComboBox(parent = panel)
        self.__comboBoxWidget.currentIndexChanged.connect(self.__set_xdata)
        lbl1 = QtGui.QLabel()
        lbl1.setText('X axis variable')
        boxLayout = QtGui.QGridLayout()
        boxLayout.addWidget(self.__comboBoxWidget,0,0,1,3)
        boxLayout.addWidget(lbl1,0,3,1,1)
        grXAxis = QtGui.QGroupBox("Select X-Data", parent = panel)
        grXAxis.setLayout(boxLayout)
    # Cursor Group Widget
        self.__ckCursor = QtGui.QCheckBox('Enable cursors')
        self.__ckCursor.stateChanged.connect(self.__CursorOn)
        self.__cur_text1 = QtGui.QLabel()
        self.__cur_text1.setText('C1: ( -.------    , -.------    )')
        self.__cur_text2 = QtGui.QLabel()
        self.__cur_text2.setText('C2: ( -.------    , -.------    )')
        self.__cur_text3 = QtGui.QLabel()
        self.__cur_text3.setText('diff:( -.------    , -.------    )')
        self.__cur_text4 = QtGui.QLabel()
        self.__cur_text4.setText('C1=')
        self.__cur_text5 = QtGui.QLabel()
        self.__cur_text5.setText('C2=')
        boxLayout = QtGui.QGridLayout()
        boxLayout.addWidget(self.__ckCursor,0,0,1,1)
        boxLayout.addWidget(self.__cur_text1,1,0,1,2)
        boxLayout.addWidget(self.__cur_text2,2,0,1,2)
        boxLayout.addWidget(self.__cur_text3,3,0,1,2)
        boxLayout.addWidget(self.__cur_text4,4,0,1,1)
        boxLayout.addWidget(self.__cur_text5,4,1,1,1)
        grCurs = QtGui.QGroupBox("Cursor", parent = panel)
        grCurs.setLayout(boxLayout)
    # Exit
        btnexit = QtGui.QPushButton('Exit')
        btnexit.clicked.connect(self.__OnClickExit)
    # Layout
        hbox.addWidget(btn0,0,0,1,1)
        hbox.addWidget(btnexit,0,1,1,1)
        hbox.addWidget(grXAxis,0,3,1,4)
        hbox.addWidget(grWave,1,3,2,4)
        hbox.addWidget(grPane,1,0,2,1)
        hbox.addWidget(grCurs,1,1,1,2)
        panel.setLayout(hbox)
    # Dock
        dock = QtGui.QDockWidget('Control Panel (detachable)', root)
        dock.setFeatures(
        #    QtGui.QDockWidget.DockWidgetMovable |
            QtGui.QDockWidget.DockWidgetFloatable)
        dock.setWidget(panel)
        root.addDockWidget(Qt.BottomDockWidgetArea, dock)

    # -----------------------------------------------------
    # Event Callbacks
    # -----------------------------------------------------
    def __OnPick(self,event):
        if isinstance(event.artist,Line2D) and self.__ckCursor.isChecked():
            if event.mouseevent.button == 1:
                self.__curName[0] = event.artist.get_label()
                self.__ydata[0] = np.array(self.__wavefile.data(self.__curName[0]))
                if self.__curName[1] is None:
                    self.__curName[1] = self.__curName[0]
                    self.__ydata[1] = self.__ydata[0]
            elif event.mouseevent.button == 3:
                self.__curName[1] = event.artist.get_label()
                self.__ydata[1] = np.array(self.__wavefile.data(self.__curName[1]))
                if self.__curName[0] is None:
                    self.__curName[0] = self.__curName[1]
                    self.__ydata[0] = self.__ydata[1]
            self.__cur_text4.setText('C1=%s' % (self.__curName[0],))
            self.__cur_text5.setText('C2=%s' % (self.__curName[1],))
            for c in [0,1]:
                x = self.__curX[c]
                y = self.__curY[c]
                if self.__ydata[c].size > 0:
                    idx1,idx2,r = self.__nearest(x,y,self.__xdata,self.__ydata[c])
                    self.__curX[c] = (1.0-r)*self.__xdata[idx1]+r*self.__xdata[idx2]
                    self.__curY[c] = (1.0-r)*self.__ydata[c][idx1]+r*self.__ydata[c][idx2]
            self.__set_cursor()
            return
        if not isinstance(event.artist,Text):
            return
        if self.__lastpane >= 0:
            self.__panes[self.__lastpane].axes.yaxis.label.set_color('black')
        for i in range(len(self.__panes)):
            if self.__panes[i].axes.yaxis.label == event.artist:
                self.__panes[i].axes.yaxis.label.set_color('red')
                self.__lastpane = i
                break
        self.__fig.canvas.draw()

    def __OnMouseMove(self,event):
        if self.__fig.canvas.widgetlock.locked():
            return
        if not event.inaxes:
            return
        if self.__xdata.size < 1:
            return
        if not self.__ckCursor.isChecked():
            return
        if event.button == 1:
            c = 0
        elif event.button == 3:
            c = 1
        else:
            return
        if self.__ydata[c].size < 1:
            return
        x = event.xdata
        if self.__curName[c] in [l.get_label() for l in event.inaxes.get_lines()]:
            y = event.ydata
        else:
            y = self.__curY[c]
        if self.__ydata[c].size > 0:
            idx1,idx2,r = self.__nearest(x,y,self.__xdata,self.__ydata[c])
            self.__curX[c] = (1.0-r)*self.__xdata[idx1]+r*self.__xdata[idx2]
            self.__curY[c] = (1.0-r)*self.__ydata[c][idx1]+r*self.__ydata[c][idx2]
            self.__set_cursor()

    def __OnClickMouse(self,event):
        lock = self.__fig.canvas.widgetlock.locked()
        cursor_visible = self.__ckCursor.isChecked()
        if event.inaxes:
            if not lock and cursor_visible:
                self.__OnMouseMove(event)
            for i in range(len(self.__panes)):
                if self.__panes[i].axes == event.inaxes:
                    if self.__lastpane != i:
                        self.__panes[self.__lastpane].axes.yaxis.label.set_color('black')
                        self.__panes[i].axes.yaxis.label.set_color('red')
                        self.__lastpane = i
                        self.__fig.canvas.draw()

    def __OnReleaseMouse(self,event):
        lock = self.__fig.canvas.widgetlock.locked() and event.inaxes
        if lock:
            if self.__ckCursor.isChecked():
                self.__cursor_set_visible(False)

    def __OnDrawEvent(self,event):
        self.__copy_from_bbox()
        self.__cursor_set_visible(True)
        self.__cursor_draw_artist()
        self.__cursor_blit()
        self.__cursor_set_visible(False)

    def __OnClickAddPane(self):
        self.add_pane()
        self.redraw()

    def __OnClickDelPane(self):
        self.del_pane()
        self.redraw()

    def __OnClickAddWave(self):
        # check some conditions
        if (self.__wavefile is None) or (self.__lastpane<0):
            return
        if not self.__wavefile.is_valid:
            return
        # get selected items and check
        items = [item.text()
                 for item in self.__listWidget.selectedItems()]
        if not items:
            return
        # add wave[s] on the last pane
        labels = self.__wavefile.get_labels()
        for sig in items:
            if sig in labels:
                self.__panes[self.__lastpane].add(sig)
        del items
        del labels
        # redraw pane
        self.__panes[self.__lastpane].redraw_pane()
        self.__fig.canvas.draw()

    def __OnClickDelWave(self):
        # check some conditions
        if self.__lastpane<0:
            return
        # get selected items
        labels = [item.text() for item in self.__listWidget.selectedItems()]
        # delete wave[s]
        for sig in labels:
            self.__panes[self.__lastpane].remove(sig)
        del labels
        # redraw pane
        self.__panes[self.__lastpane].redraw_pane()
        self.__fig.canvas.draw()

    def __CursorOn(self):
        self.__set_cursor()

    def __OnClickExit(self):
        msg = QtGui.QMessageBox()
        msg.setIcon(QtGui.QMessageBox.Question)
        msg.setText("Are you sure you want to exit?")
        msg.setWindowTitle("Confirmation")
        msg.setStandardButtons(QtGui.QMessageBox.Yes | QtGui.QMessageBox.Cancel)
        retval = msg.exec_()
        if retval == QtGui.QMessageBox.Cancel:
            return
        plt.close()

    def __OnClickOpenFile(self):
        # file open dialog
        filename,filetype = QtGui.QFileDialog.getOpenFileName(
            self.panel, u'Select Waveform File',
            os.path.dirname(self.__wavefilepath),
            'gSpiceUI format (*.tr);;GnuCap format (*);;Ngspice format (*)')
        if not filename:
            return
        # check filetype
        if filetype == u'gSpiceUI format (*.tr)':
            self.set_file(filename,CReaderGSpiceUI())
        elif filetype == u'GnuCap format (*)':
            self.set_file(filename,CReaderGnucap())
        elif filetype == u'Ngspice format (*)':
            self.set_file(filename,CReaderNgspice())
        else:
            return
        # update control panel
        del filename
        del filetype
#        for p in self.__panes:
#            p.redraw_pane()
        self.redraw()
        self.__set_xdata()

    def __set_xdata(self):
        self.__xlabel = self.__comboBoxWidget.currentText()
        if not self.__xlabel:
            return
        self.__xdata = np.array(self.__wavefile.data(self.__xlabel))
        self.__ckCursor.setCheckState(QtCore.Qt.Unchecked)
        for p in self.__panes:
            p.xlabel = self.__xlabel
            p.redraw_pane()
        self.__refresh_canvas()

# #########################################################

if __name__ == '__main__':

    try:
        argc = len(argv)

        wv = WaveViewerWindow()
        if argc > 1:
            wv.set_file(argv[1],CReaderGSpiceUI())
        wv.add_pane()
        wv.redraw()

        plt.show()
    except:
        pass
#        print 'Error'

