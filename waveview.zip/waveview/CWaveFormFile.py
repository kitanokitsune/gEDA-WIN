#################################
# Waveform File Container Class #
#################################

from os.path import exists, basename
from os import stat

class CWaveFormFile(object):
    def __init__(self, file, reader):
        self.reader = reader
        self.filename = file
        self.set_file(file)

    def __my_init__(self):
        self.dim    = 0
        self.points = 0
        self.timestamp = None
        self.is_valid = False

    def set_file(self, fname):
        self.__my_init__()
        if exists(fname):
            self.filename = fname
            self.timestamp = stat(fname).st_mtime
            self.is_valid = self.reader.set_file(self.filename)
            if self.is_valid:
                self.dim = len(self.get_labels())
                self.points = len(self.get_data(0))
                if self.dim < 1 or self.points < 1:
                    self.is_valid = False
                    self.__my_init__()
        else:
            self.__my_init__()
        return self.is_valid

    def is_file_updated(self):
        if self.filename is None:
            return False
        if not exists(self.filename):
            self.__my_init__()
            return False
        timestamp = stat(self.filename).st_mtime
        return (timestamp != self.timestamp)

    def reload_file(self):
        return self.set_file(self.filename)

    def get_size(self):
        return (self.dim, self.points)

    def get_basename(self):
        if self.filename:
            return basename(self.filename)
        else:
            return ''

    def get_labels(self):
        if self.is_valid:
            return self.reader.get_labels()
        return []

    def get_data(self,n):
        if self.is_valid:
            return self.reader.get_data(n)
        return []

    def data(self,key):
        labels = self.get_labels()
        if self.is_valid and (key in labels):
            return self.reader.get_data(labels.index(key))
        return []

